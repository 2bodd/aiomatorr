// Follow Deno and Edge Function conventions
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { SMTPClient } from "https://deno.land/x/smtp@v0.7.0/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const formData = await req.json();

    // Honeypot check
    if (formData.honeypot) {
      return new Response(
        JSON.stringify({ error: 'Invalid submission' }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Validate required fields
    const requiredFields = ['name', 'email', 'companyName', 'phoneNumber', 'importantQuestion', 'findUs', 'adSpend', 'website'];
    for (const field of requiredFields) {
      if (!formData[field]) {
        return new Response(
          JSON.stringify({ error: `${field} is required` }),
          { 
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          }
        );
      }
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      return new Response(
        JSON.stringify({ error: 'Invalid email format' }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Create email client
    const client = new SMTPClient({
      connection: {
        hostname: Deno.env.get('SMTP_HOST') || '',
        port: parseInt(Deno.env.get('SMTP_PORT') || '587'),
        tls: false,
        auth: {
          username: Deno.env.get('SMTP_USER') || '',
          password: Deno.env.get('SMTP_PASS') || '',
        },
      }
    });

    // Format email content
    const emailContent = `
      New AI Analysis Request

      Name: ${formData.name}
      Email: ${formData.email}
      Company: ${formData.companyName}
      Phone: ${formData.phoneNumber}
      Important Question: ${formData.importantQuestion}
      Found Us Through: ${formData.findUs}
      Monthly Ad Spend: ${formData.adSpend}
      Website: ${formData.website}
    `;

    try {
      // Send email
      await client.send({
        from: Deno.env.get('SMTP_FROM') || '',
        to: 'info@aiomator.com',
        subject: 'New AI Analysis Request',
        content: emailContent,
      });

      await client.close();

      return new Response(
        JSON.stringify({ message: 'Email sent successfully' }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    } catch (emailError) {
      console.error('Email sending failed:', emailError);

      // Fallback: Log submission to a file
      const timestamp = new Date().toISOString();
      const logEntry = `
        ========================================
        Timestamp: ${timestamp}
        ${emailContent}
        ========================================\n
      `;

      await Deno.writeTextFile('/tmp/form-submissions.log', logEntry, { append: true });

      return new Response(
        JSON.stringify({ 
          message: 'Form submission received. We will contact you soon.',
          warning: 'Email delivery delayed, but submission was logged.'
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }
  } catch (error) {
    console.error('Form submission error:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to process form submission. Please try again.' }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});