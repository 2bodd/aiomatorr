export default function About() {
  return (
    <div className="min-h-screen bg-black pt-24 pb-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold text-white mb-8">About Aiomator</h1>
        
        <div className="prose prose-invert max-w-none">
          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-white mb-4">Our Mission</h2>
            <p className="text-gray-400 mb-4">
              At Aiomator, we're dedicated to helping pet supply store owners unlock the full potential of AI technology.
              We understand the unique challenges you face in today's competitive market — from managing endless customer
              inquiries to maximizing sales opportunities and controlling operational costs.
            </p>
            <p className="text-gray-400">
              Our mission is to empower pet supply stores to grow faster and operate smarter with AI solutions that deliver
              real, measurable results. We believe that technology should be simple, powerful, and make your life easier.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-white mb-4">What We Do</h2>
            <p className="text-gray-400 mb-4">
              We specialize in creating AI agents that work 24/7, handling customer support, driving sales, and reducing
              operational costs. Our AI solutions are specifically designed for pet supply stores, understanding the nuances
              of pet products, care advice, and customer service needs in your industry.
            </p>
            <p className="text-gray-400">
              Unlike traditional support staff, our AI agents never get tired, never call in sick, and continuously learn
              and improve. They can handle multiple conversations simultaneously, provide instant responses, and maintain
              consistent service quality around the clock.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-white mb-4">Our Commitment</h2>
            <p className="text-gray-400 mb-4">
              We're committed to your success. That's why we offer a risk-free guarantee: if our AI doesn't help you save
              time and boost sales in the first 30 days, you don't pay a penny. We believe in building long-term
              partnerships with our clients, providing ongoing support and continuously improving our solutions based on
              your feedback and needs.
            </p>
            <p className="text-gray-400">
              Our team combines expertise in AI technology with deep understanding of the pet supply industry, ensuring
              that our solutions are not just technically advanced but also practically valuable for your business.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}