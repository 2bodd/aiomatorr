export default function Thanks() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="text-center px-4 max-w-2xl mx-auto">
        <h1 className="text-4xl font-bold text-white mb-6">Thank You!</h1>
        <p className="text-gray-400 text-lg mb-8">
          Our team is reviewing your store details. We'll email you shortly to schedule your free AI consultation.
        </p>
        <a 
          href="/" 
          className="text-blue-400 hover:text-blue-300 font-bold text-lg transition-colors"
        >
          Back to Home
        </a>
      </div>
    </div>
  );
}