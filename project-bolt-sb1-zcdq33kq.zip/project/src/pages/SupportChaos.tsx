import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

export default function SupportChaos() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4">
      <div className="max-w-3xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Welcome to Support Chaos
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-400 mb-8">
            You chose to stay overwhelmed. Enjoy losing $257/day while your competitors thrive. 😉
          </p>
          
          <p className="text-lg text-gray-500 mb-12">
            No worries — we'll be here when you're ready to escape the chaos and scale with AI.
          </p>

          <motion.button
            onClick={() => navigate('/')}
            className="px-8 py-4 bg-blue-600 text-white text-lg font-bold rounded-lg
              shadow-lg hover:shadow-blue-500/25 hover:scale-105
              transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Take Me Back — I'm Ready for AI Power 🚀
          </motion.button>
        </motion.div>
      </div>
    </div>
  );
}