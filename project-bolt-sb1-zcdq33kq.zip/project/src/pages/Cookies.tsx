export default function Cookies() {
  return (
    <div className="min-h-screen bg-black pt-24 pb-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold text-white mb-8">Cookies Policy</h1>
        
        <div className="prose prose-invert max-w-none">
          <p className="text-gray-300 mb-6">Last updated: {new Date().toLocaleDateString()}</p>
          
          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-white mb-4">1. What Are Cookies</h2>
            <p className="text-gray-300">
              Cookies are small text files that are placed on your device when you visit our website. They help us provide you with a better experience and understand how you interact with our services.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-white mb-4">2. How We Use Cookies</h2>
            <p className="text-gray-300 mb-4">We use cookies for the following purposes:</p>
            <ul className="list-disc pl-6 text-gray-300 space-y-2">
              <li>Essential cookies for website functionality</li>
              <li>Analytics cookies to improve our service</li>
              <li>Preference cookies to remember your settings</li>
              <li>Marketing cookies for relevant content</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-white mb-4">3. Managing Cookies</h2>
            <p className="text-gray-300">
              You can control and/or delete cookies as you wish. You can delete all cookies that are already on your computer and you can set most browsers to prevent them from being placed.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-white mb-4">4. Types of Cookies We Use</h2>
            <ul className="list-disc pl-6 text-gray-300 space-y-2">
              <li>Session Cookies: Temporary cookies that expire when you close your browser</li>
              <li>Persistent Cookies: Remain on your device for a set period</li>
              <li>First-party Cookies: Set by our website</li>
              <li>Third-party Cookies: Set by our partners and service providers</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-white mb-4">5. Contact Us</h2>
            <p className="text-gray-300">
              If you have any questions about our use of cookies, please contact us through our website contact form.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}