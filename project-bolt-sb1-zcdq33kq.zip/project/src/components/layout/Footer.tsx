import { Link, useLocation } from 'react-router-dom';
import { useNavigation } from '@/utils/useNavigation';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  const { navigateAndScroll, goToAnalysis } = useNavigation();
  const location = useLocation();
  const isHomePage = location.pathname === '/';

  return (
    <footer className="bg-gradient-to-b from-[#0B0F1C] to-black text-white">
      {isHomePage && (
        <div className="border-t border-white/10">
          <div className="max-w-7xl mx-auto">
            {/* Header Section */}
            <div className="text-center py-16">
              <h2 className="text-6xl sm:text-7xl font-extrabold tracking-tight text-white mb-6">
                The Choice Is Yours
              </h2>
              <p className="text-xl text-gray-400 max-w-2xl mx-auto">
                Will you keep drowning in support chaos — or let AI take over, while you scale in peace?
              </p>
            </div>

            {/* Choice Cards */}
            <div className="grid md:grid-cols-2 gap-12 px-4 max-w-6xl mx-auto">
              {/* Left Card - Do Nothing */}
              <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-b from-[#1a1c20]/60 to-black rounded-2xl" />
                <div className="relative p-8 border border-white/10 rounded-2xl hover:border-[#4B5563] transition-all duration-300 backdrop-blur-md">
                  <div className="flex items-center gap-2 mb-8">
                    <div className="w-2 h-2 rounded-full bg-[#7F1D1D]" />
                    <p className="text-[#DC2626] uppercase tracking-wider text-sm font-semibold">KEEP STRUGGLING</p>
                  </div>
                  <ul className="space-y-6 mb-8 text-sm">
                    {[
                      "Lose $257 daily to slow responses",
                      "Watch customers buy from competitors",
                      "Waste 6h/day on repetitive questions",
                      "Keep paying $3,500/month for staff support",
                    ].map((text, index) => (
                      <li key={index} className="flex items-center gap-3 text-gray-300">
                        <span className="text-[#DC2626] text-2xl">❌</span>
                        <span>{text}</span>
                      </li>
                    ))}
                  </ul>
                  <button 
                    onClick={() => navigateAndScroll('/support-chaos')}
                    className="w-full px-8 py-4 bg-[#1f2937] text-gray-300 rounded-lg border border-gray-600 hover:bg-[#374151] transition-all duration-300 uppercase tracking-wider font-bold shadow-md hover:shadow-red-900/30"
                  >
                    STAY OVERWHELMED
                  </button>
                </div>
              </div>

              {/* Right Card - Take Action */}
              <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-b from-[#1E40AF]/20 to-black rounded-2xl" />
                <div className="relative p-8 border border-white/10 rounded-2xl hover:border-blue-400/30 transition-all duration-300 backdrop-blur-md">
                  <div className="flex items-center gap-2 mb-8">
                    <div className="w-2 h-2 rounded-full bg-blue-500" />
                    <p className="text-blue-400 uppercase tracking-wider text-sm font-semibold">TAKE ACTION NOW</p>
                  </div>
                  <ul className="space-y-6 mb-8 text-sm">
                    {[
                      "AI answers 83% of questions instantly",
                      "Save $3,500+ monthly on staff costs",
                      "Boost sales 40% while you sleep",
                      "$0 risk — pay only if we save you money",
                    ].map((text, index) => (
                      <li key={index} className="flex items-center gap-3 text-gray-300">
                        <span className="text-blue-400 text-2xl">✓</span>
                        <span>{text}</span>
                      </li>
                    ))}
                  </ul>
                  <button
                    onClick={goToAnalysis}
                    className="w-full px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition-all duration-300 uppercase tracking-wide shadow-xl hover:shadow-blue-500/30"
                  >
                    GET YOUR FREE AI PLAN NOW →
                  </button>
                </div>
              </div>
            </div>

            {/* Bottom Section */}
            <div className="text-center py-16">
              <p className="text-2xl text-gray-400 mb-8 max-w-2xl mx-auto">
                Don't let another day of lost sales and wasted time slip away.
                Take the first step toward freedom TODAY.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Standard Footer Content */}
      <div className="border-t border-white/10 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center space-y-6">
            <Link 
              to="/" 
              onClick={() => navigateAndScroll('/')}
              className="text-2xl font-bold hover:opacity-80 transition-opacity"
            >
              <span className="text-blue-400">Ai</span>
              <span className="text-gray-100">omator</span>
            </Link>
            <div className="flex justify-center space-x-8 text-sm text-gray-400">
              <Link 
                to="/about" 
                onClick={() => navigateAndScroll('/about')}
                className="hover:text-white transition-colors"
              >
                About Us
              </Link>
              <Link 
                to="/contact"
                onClick={() => navigateAndScroll('/contact')}
                className="hover:text-white transition-colors"
              >
                Contact
              </Link>
              <Link 
                to="/privacy"
                onClick={() => navigateAndScroll('/privacy')}
                className="hover:text-white transition-colors"
              >
                Privacy Policy
              </Link>
              <Link 
                to="/cookies"
                onClick={() => navigateAndScroll('/cookies')}
                className="hover:text-white transition-colors"
              >
                Cookies Policy
              </Link>
            </div>
            <div className="text-sm text-gray-400">
              © {currentYear} Aiomator. All rights reserved.
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}