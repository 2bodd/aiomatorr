import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { useNavigation } from '@/utils/useNavigation';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { goToAnalysis, navigateAndScroll } = useNavigation();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-lg border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link 
            to="/" 
            onClick={() => navigateAndScroll('/')}
            className="flex items-center"
          >
            <span className="text-2xl font-bold">
              <span className="text-primary-500">Ai</span>
              <span className="text-gray-100">omator</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link
              to="/"
              onClick={() => navigateAndScroll('/')}
              className="text-gray-300 hover:text-white transition-colors"
            >
              Home
            </Link>
            <button
              onClick={goToAnalysis}
              className="text-gray-300 hover:text-white transition-colors"
            >
              Free AI Analysis
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-gray-300 hover:text-white"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-black/95 border-b border-white/10">
          <div className="px-4 py-4 space-y-3">
            <Link
              to="/"
              onClick={() => {
                navigateAndScroll('/');
                setIsOpen(false);
              }}
              className="block text-center px-4 py-2 rounded-lg text-gray-300 hover:text-white hover:bg-white/5 transition-all"
            >
              Home
            </Link>
            <button
              onClick={() => {
                goToAnalysis();
                setIsOpen(false);
              }}
              className="block w-full text-center px-4 py-2 rounded-lg text-gray-300 hover:text-white hover:bg-white/5 transition-all"
            >
              Free AI Analysis
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}