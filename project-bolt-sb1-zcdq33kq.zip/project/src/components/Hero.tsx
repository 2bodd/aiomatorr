import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-black via-purple-900/20 to-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
        <div className="animate-fade-in">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold text-white mb-8">
            More Freedom. More Efficiency.
            <span className="bg-gradient-to-r from-purple-400 to-purple-600 text-transparent bg-clip-text"> Guaranteed.</span>
          </h1>
          <p className="text-xl text-gray-300 mb-12 max-w-3xl mx-auto">
            Tailored AI solutions to streamline operations and maximize efficiency
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#services"
              className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700"
            >
              Our Services
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
            <a
              href="https://calendly.com/ebdhadd/30min_call"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-8 py-3 border border-purple-300 text-base font-medium rounded-md text-purple-300 hover:bg-purple-900/20"
            >
              Schedule a Call
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}