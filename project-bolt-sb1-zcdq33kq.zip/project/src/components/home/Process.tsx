import { Search, Code, LineChart } from 'lucide-react';

const steps = [
  {
    id: '01',
    title: 'Discover',
    description: 'We analyze your business needs and identify high-impact AI opportunities for maximum ROI.',
    icon: Search,
    metrics: [
      { label: 'Analysis completed in', value: '1-2 days' }
    ]
  },
  {
    id: '02',
    title: 'Develop & Deploy',
    description: 'Our team builds and implements secure, tailored AI solutions designed for your specific needs.',
    icon: Code,
    metrics: [
      { label: 'Development time', value: '3-4 days' }
    ]
  },
  {
    id: '03',
    title: 'Optimize',
    description: 'Continuous monitoring and updates ensure your AI solutions evolve with your business needs.',
    icon: LineChart,
    metrics: [
      { label: 'Performance boost', value: '+38%' },
      { label: 'Cost reduction', value: '-25%' }
    ]
  }
];

export default function Process() {
  return (
    <section id="process" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-5xl sm:text-6xl font-bold mb-4">
            <span className="bg-gradient-to-br from-white via-white to-blue-500 text-transparent bg-clip-text drop-shadow-sm">
              Our Process
            </span>
          </h2>
          <p className="text-xl text-gray-400 mx-auto max-w-2xl">
            A proven approach to implementing AI solutions that drive results
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div key={step.id} className="relative p-6 rounded-lg bg-gray-900/50">
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-4 w-8 h-0.5 bg-blue-600" />
              )}
              <step.icon className="h-12 w-12 text-blue-500 mb-6" />
              <div className="space-y-4">
                <div className="flex items-baseline gap-2">
                  <span className="text-blue-400 font-mono">{step.id}</span>
                  <h3 className="text-2xl font-semibold text-white">{step.title}</h3>
                </div>
                <p className="text-gray-400">{step.description}</p>
                {step.metrics.length > 0 && (
                  <div className="space-y-2 mt-4">
                    {step.metrics.map((metric) => (
                      <div key={metric.label} className="flex justify-between items-center">
                        <span className="text-gray-400">{metric.label}</span>
                        <span className="font-mono text-blue-400">{metric.value}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}