import { Calendar, Mail, Phone } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div>
            <h2 className="text-5xl sm:text-6xl font-bold mb-8">
              Let's Build Your{' '}
              <span className="bg-gradient-to-r from-blue-400 to-blue-600 text-transparent bg-clip-text">
                AI-Powered Future
              </span>
            </h2>
            <p className="text-gray-400 mb-8 text-lg">
              Book a free 30-minute consultation to discuss how we can help transform your business with AI automation.
            </p>
            <div className="bg-gray-900/50 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-white mb-4">What to Expect:</h3>
              <ul className="space-y-4">
                <li className="flex items-center gap-3 text-gray-300">
                  <Calendar className="h-5 w-5 text-blue-400" />
                  Get a tailored AI strategy for your business
                </li>
                <li className="flex items-center gap-3 text-gray-300">
                  <Mail className="h-5 w-5 text-blue-400" />
                  Discuss pricing and implementation timelines
                </li>
                <li className="flex items-center gap-3 text-gray-300">
                  <Phone className="h-5 w-5 text-blue-400" />
                  Receive expert recommendations
                </li>
              </ul>
            </div>
          </div>
          <div className="bg-gray-900/50 p-6 rounded-lg">
            <iframe
              src="https://calendly.com/ebdhadd/30min_call"
              width="100%"
              height="600"
              frameBorder="0"
              title="Schedule a call"
              className="rounded-lg"
            />
          </div>
        </div>
      </div>
    </section>
  );
}