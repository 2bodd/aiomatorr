import { useState } from 'react';
import { Phone, AlertCircle, UserX, Zap, Shield, Target, MapPin, Focus } from 'lucide-react';
import { useNavigation } from '@/utils/useNavigation';
import { motion } from 'framer-motion';

interface FlipCardProps {
  icon: typeof Phone;
  title: string;
  description: string;
  solution: string;
  iconColor: string;
  gradientFrom: string;
  gradientTo: string;
}

function FlipCard({ icon: Icon, title, description, solution, iconColor, gradientFrom, gradientTo }: FlipCardProps) {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div
      className="relative h-[300px] w-full perspective-1000 cursor-pointer group"
      onMouseEnter={() => setIsFlipped(true)}
      onMouseLeave={() => setIsFlipped(false)}
      onClick={() => setIsFlipped(!isFlipped)}
    >
      <motion.div
        className="w-full h-full relative preserve-3d transition-transform duration-700"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.7, ease: [0.23, 0.86, 0.39, 0.96] }}
      >
        {/* Front of card */}
        <div className="absolute inset-0 p-8 rounded-2xl backface-hidden overflow-hidden">
          {/* Gradient background */}
          <div className={`absolute inset-0 bg-gradient-to-br ${gradientFrom} ${gradientTo} opacity-10`} />
          
          {/* Glass effect border */}
          <div className="absolute inset-0 border border-white/10 rounded-2xl backdrop-blur-sm" />
          
          {/* Content */}
          <div className="relative z-10 h-full flex flex-col items-center text-center">
            <div className={`w-16 h-16 ${iconColor} rounded-2xl flex items-center justify-center mb-6 transform group-hover:scale-110 transition-transform duration-300`}>
              <Icon className="w-8 h-8" />
            </div>
            <h3 className="text-3xl font-bold tracking-tight mb-4">{title}</h3>
            <p className="text-gray-400 text-lg leading-relaxed">
              {description}
            </p>
          </div>
        </div>

        {/* Back of card */}
        <div className="absolute inset-0 p-8 rounded-2xl backface-hidden rotate-y-180 overflow-hidden">
          {/* Gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-600/20 to-blue-600/20 opacity-20" />
          
          {/* Glass effect border */}
          <div className="absolute inset-0 border border-emerald-500/20 rounded-2xl backdrop-blur-sm" />
          
          {/* Content */}
          <div className="relative z-10 h-full flex flex-col justify-center">
            <div className="bg-emerald-500/10 rounded-xl p-6 border border-emerald-500/20">
              <div className="flex items-center gap-2 mb-4">
                <Zap className="w-5 h-5 text-emerald-400" />
                <h4 className="text-emerald-400 text-xl font-semibold">Our Solution</h4>
              </div>
              <p className="text-gray-300 leading-relaxed">
                {solution}
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default function ProblemSolution() {
  const { goToAnalysis } = useNavigation();

  const cards: FlipCardProps[] = [
    {
      icon: Phone,
      title: "Endless Questions",
      description: "Your inbox is flooded 24/7 with product questions, order updates, and pet advice. Time vanishes into an endless support cycle.",
      solution: "Our AI handles 83% of inquiries instantly, providing accurate product info and pet care advice 24/7. Reclaim your time while delivering better service.",
      iconColor: "bg-red-500/20 text-red-500",
      gradientFrom: "from-red-500/20",
      gradientTo: "to-orange-500/20"
    },
    {
      icon: AlertCircle,
      title: "Lost Sales",
      description: "Every delayed response sends another customer to Chewy or PetSmart. Your competition never sleeps.",
      solution: "Convert browsers into buyers with instant responses and smart product recommendations. Capture sales 24/7, even at 3 AM.",
      iconColor: "bg-blue-500/20 text-blue-500",
      gradientFrom: "from-blue-500/20",
      gradientTo: "to-purple-500/20"
    },
    {
      icon: UserX,
      title: "Staff Burnout",
      description: "The endless cycle of hiring, training, and replacing support staff drains your resources and energy.",
      solution: "Replace unreliable staff with AI that never calls in sick, never quits, and gets smarter every day. Cut costs while improving service.",
      iconColor: "bg-amber-500/20 text-amber-500",
      gradientFrom: "from-amber-500/20",
      gradientTo: "to-red-500/20"
    }
  ];

  return (
    <section className="py-32 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-32">
          <h2 className="text-6xl sm:text-7xl font-bold tracking-tight text-white mb-16">
            Overwhelmed with 24/7 Customer Support Requests?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {cards.map((card, index) => (
              <FlipCard key={index} {...card} />
            ))}
          </div>
        </div>

        {/* Results Section */}
        <div className="text-center mb-32">
          <h2 className="text-6xl sm:text-7xl font-bold tracking-tight text-white mb-16">
            <span className="bg-gradient-to-r from-primary-400 to-secondary-400 text-transparent bg-clip-text">
              What Could You Do With 40+ Extra Hours Per Month?
            </span>
          </h2>
          
          <div className="text-xl text-gray-300 max-w-3xl mx-auto mb-16 space-y-6">
            <p>What if you could…</p>
            <ul className="list-none space-y-4">
              <li>– Launch that new product line?</li>
              <li>– Spend more time with family?</li>
              <li>– Finally get a full night's sleep?</li>
            </ul>
            <p className="text-green-400">→ All while boosting sales in the background.</p>
          </div>

          {/* Results Table */}
          <div className="max-w-3xl mx-auto">
            <div className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 mb-12">
              <Zap className="w-5 h-5 mr-3" />
              How AI Can Improve Your Store
            </div>

            <div className="overflow-hidden rounded-xl border border-gray-800 mb-16">
              <div className="divide-y divide-gray-800">
                {/* Table Headers */}
                <div className="grid grid-cols-3 text-base md:text-lg">
                  <div className="bg-gray-900/30 p-6 font-medium text-gray-300">Metric</div>
                  <div className="bg-gray-900/30 p-6 font-medium text-gray-300">Before AI</div>
                  <div className="bg-gray-900/30 p-6 font-medium text-gray-300">After AI</div>
                </div>
                {/* Row 1 */}
                <div className="grid grid-cols-3 text-base md:text-lg">
                  <div className="p-6 font-medium text-white">Response Time</div>
                  <div className="p-6 text-red-400">Several Hours</div>
                  <div className="p-6 text-green-400">Under a Minute</div>
                </div>
                {/* Row 2 */}
                <div className="grid grid-cols-3 text-base md:text-lg">
                  <div className="p-6 font-medium text-white">Monthly Sales</div>
                  <div className="p-6 text-red-400">Inconsistent</div>
                  <div className="p-6 text-green-400">Steadily Increasing</div>
                </div>
                {/* Row 3 */}
                <div className="grid grid-cols-3 text-base md:text-lg">
                  <div className="p-6 font-medium text-white">Support Costs</div>
                  <div className="p-6 text-red-400">Too High</div>
                  <div className="p-6 text-green-400">Significantly Lower</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Why Choose Us Section */}
        <div>
          <h2 className="text-6xl sm:text-7xl font-bold tracking-tight text-white text-center mb-16">
            Why Pet Stores Choose Us
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="p-10 rounded-2xl bg-gray-900/50 border border-primary-500/20 hover:border-primary-500/40 transition-all duration-300">
              <Shield className="w-14 h-14 text-green-400 mb-6" />
              <h3 className="text-3xl font-bold tracking-tight mb-6">100% RISK-FREE GUARANTEE</h3>
              <p className="text-gray-300 text-lg">
                If our AI doesn't help you save time and boost sales in the first 30 days, you don't pay a penny. No risk, just results.
              </p>
            </div>

            <div className="p-10 rounded-2xl bg-gray-900/50 border border-primary-500/20 hover:border-primary-500/40 transition-all duration-300">
              <Target className="w-14 h-14 text-green-400 mb-6" />
              <h3 className="text-3xl font-bold tracking-tight mb-6">PROVEN RESULTS</h3>
              <p className="text-gray-300 text-lg">
                40% more sales, 83% less support work, and happier customers — all within your first month. Backed by real data.
              </p>
            </div>

            <div className="p-10 rounded-2xl bg-gray-900/50 border border-primary-500/20 hover:border-primary-500/40 transition-all duration-300">
              <MapPin className="w-14 h-14 text-green-400 mb-6" />
              <h3 className="text-3xl font-bold tracking-tight mb-6">LOCAL SUPPORT</h3>
              <p className="text-gray-300 text-lg">
                We're not a faceless overseas agency. You can voice note us, call us, or meet us if you're nearby. Real human support, powered by cutting-edge AI.
              </p>
            </div>

            <div className="p-10 rounded-2xl bg-gray-900/50 border border-primary-500/20 hover:border-primary-500/40 transition-all duration-300">
              <Focus className="w-14 h-14 text-green-400 mb-6" />
              <h3 className="text-3xl font-bold tracking-tight mb-6">PET INDUSTRY EXPERTS</h3>
              <p className="text-gray-300 text-lg">
                Our AI is trained specifically for pet stores. From nutrition advice to product recommendations, we know your business.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}