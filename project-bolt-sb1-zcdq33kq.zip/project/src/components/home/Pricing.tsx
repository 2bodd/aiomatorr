import { Check } from 'lucide-react';

const plans = [
  {
    name: 'Basic',
    gradient: 'from-blue-400/20',
    description: 'For businesses looking to start with AI and automations.',
    features: [
      '1 Developer',
      'Basic chatbots & Model',
      '5 Monthly Check Ups',
      'Cancel & pause anytime'
    ]
  },
  {
    name: 'Professional',
    gradient: 'from-blue-500/20',
    description: 'For businesses looking to outperform their competition with AI and automations.',
    features: [
      '2 developers',
      'Custom chatbots & Models',
      '15 Monthly Check Ups',
      'Cancel & pause anytime'
    ]
  },
  {
    name: 'Enterprise',
    gradient: 'from-blue-600/20',
    description: 'For businesses looking to fully leverage AI and automations to become an industry leader.',
    features: [
      '3 developers',
      'Premium Custom chatbots & Models',
      'Unlimited Check Ups',
      'Cancel & pause anytime'
    ]
  }
];

export default function Pricing() {
  return (
    <section id="pricing" className="relative py-32 bg-black overflow-hidden">
      {/* Background Glow Effect */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(37,99,235,0.1)_0%,transparent_65%)]" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 relative">
          {/* Title Glow Effect */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-blue-600/20 rounded-full blur-[100px] -z-10" />
          
          <h2 className="text-7xl font-bold tracking-tight">
            <span className="bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
              Subscriptions
            </span>
          </h2>
          <p className="mt-4 text-lg text-gray-400">
            Three different subscriptions to match your companies' needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div
              key={plan.name}
              className={`relative group ${index === 1 ? 'z-10' : ''}`}
            >
              {/* Enhanced animated glow effect for Professional plan */}
              {index === 1 && (
                <div className="absolute inset-0 bg-blue-600/20 rounded-[30px] blur-[50px] -z-10 animate-pulse-slow" />
              )}
              
              {/* Card Background with Gradient */}
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-b ${plan.gradient} to-transparent opacity-20`} />
              
              <div className="relative h-full p-8 rounded-2xl bg-black/50 backdrop-blur-sm border border-white/10 transition-all duration-300 hover:border-blue-500/50">
                <div className="mb-8">
                  <h3 className="inline-flex text-2xl font-medium">
                    <span className="bg-gradient-to-r from-white to-blue-400 bg-clip-text text-transparent">
                      {plan.name}
                    </span>
                  </h3>
                  <p className="mt-4 text-gray-400 text-sm">
                    {plan.description}
                  </p>
                </div>

                <button 
                  onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                  className="w-full px-6 py-3 mb-8 rounded-lg bg-black border border-white/10 text-white hover:bg-blue-600/10 hover:border-blue-500/50 transition-all duration-300"
                >
                  Book Your Call
                </button>

                <div className="space-y-4">
                  {plan.features.map((feature) => (
                    <div key={feature} className="flex items-center gap-3">
                      <Check className="h-5 w-5 text-blue-400 flex-shrink-0" />
                      <span className="text-gray-400 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}