import { Brain, Workflow, Clock, Zap } from 'lucide-react';
import { ServiceCard } from '@/components/ui/ServiceCard';

const services = [
  {
    title: 'Intelligent Task Automation',
    description: 'AI agents that handle complex workflows, make decisions, and execute actions – just like your best employees would.',
    icon: Brain,
    link: '#contact'
  },
  {
    title: 'End-to-End Process Management',
    description: 'From initial customer contact to final delivery, our agents manage entire workflows without human intervention.',
    icon: Workflow,
    link: '#contact'
  },
  {
    title: '24/7 Business Operations',
    description: 'Your AI workforce never sleeps, ensuring consistent service and rapid response times around the clock.',
    icon: Clock,
    link: '#contact'
  },
  {
    title: 'Rapid Implementation',
    description: 'From concept to deployment in 48 hours. Start saving time and reducing costs immediately.',
    icon: Zap,
    link: '#contact'
  }
];

export default function Services() {
  return (
    <section id="services" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-5xl sm:text-6xl font-bold mb-4">
            <span className="bg-gradient-to-br from-white via-white to-blue-500 text-transparent bg-clip-text drop-shadow-sm">
              AI-Powered Systems
            </span>
          </h2>
          <p className="text-xl text-gray-400 mx-auto max-w-2xl">
            Replace entire teams with intelligent AI agents that handle complex workflows
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service) => (
            <ServiceCard key={service.title} {...service} />
          ))}
        </div>
      </div>
    </section>
  );
}