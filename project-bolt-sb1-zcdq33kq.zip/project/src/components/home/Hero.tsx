import { useNavigation } from '@/utils/useNavigation';
import { HeroGeometric } from '@/components/ui/hero-geometric';

export default function Hero() {
  const { goToAnalysis } = useNavigation();

  return (
    <HeroGeometric 
      title1="Get a 24/7 AI Support Agent"
      title2="for Your Pet Store"
      subtitle={<>Handle <span style={{ color: '#00FFAB' }}>83% of customer questions in just 9 seconds</span> — no more missed sales, no more late-night replies.</>}
      bulletPoints={[
        "$3,287/month saved by replacing support staff",
        "40% more sales from instant AI recommendations",
        "Zero risk — Pay only if we deliver results"
      ]}
      ctaButton={{
        mainText: "Unlock Your Free AI Analysis",
        subText: "(LAST 2 SPOTS!)"
      }}
      onCtaClick={goToAnalysis}
    />
  );
}