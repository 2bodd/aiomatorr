{/* Previous imports remain the same */}

export default function Problem() {
  return (
    <section id="problem" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Problem Statement */}
        <div className="text-center mb-16 space-y-4 relative">
          {/* Title Glow Effect */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-blue-600/20 rounded-full blur-[100px] -z-10" />
          
          <h2 className="text-5xl sm:text-6xl font-bold">
            <span className="bg-gradient-to-br from-white via-white to-blue-500 text-transparent bg-clip-text drop-shadow-sm">
              AI is Taking Over—Are You Ready?
            </span>
          </h2>
          {/* Rest of the content remains the same until the button */}
          
          <button
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="mt-12 inline-flex items-center justify-center px-8 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-blue-800 text-white shadow-lg hover:shadow-blue-500/25 transition-all duration-200 text-sm font-medium w-auto"
          >
            Start Your AI Journey Now
          </button>
        </div>
      </div>
    </section>
  );
}