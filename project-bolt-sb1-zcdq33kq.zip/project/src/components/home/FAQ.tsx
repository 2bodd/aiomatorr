import { useState } from 'react';
import { Plus } from 'lucide-react';

const faqs = [
  {
    question: 'Is my company a good fit for You?',
    answer: 'If your business is looking to streamline operations, improve customer service, or automate repetitive tasks using AI, then yes! We work with companies of all sizes across various industries.'
  },
  {
    question: 'How long does it take to implement my requests?',
    answer: 'Implementation time varies based on complexity, but most solutions are deployed within 1-2 weeks. We prioritize quick, efficient delivery without compromising quality.'
  },
  {
    question: 'Are your solutions secure?',
    answer: 'Security is our top priority. We implement enterprise-grade security measures, including data encryption, secure API endpoints, and regular security audits.'
  },
  {
    question: "How many AI can I integrate?",
    answer: "There's no strict limit. We can integrate multiple AI solutions based on your needs, ensuring they work together seamlessly for maximum efficiency."
  },
  {
    question: 'Do you offer continuous support?',
    answer: 'Yes, all our plans include ongoing support and regular check-ups. Our team is always available to help optimize and maintain your AI solutions.'
  },
  {
    question: 'Can I cancel my subscription at any time?',
    answer: 'Absolutely! All our plans are flexible with no long-term commitments. You can cancel or pause your subscription whenever you need to.'
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="faq" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 relative">
          {/* Title Glow Effect */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-blue-600/20 rounded-full blur-[100px] -z-10" />
          
          <h2 className="text-5xl sm:text-6xl font-bold mb-4">
            <span className="bg-gradient-to-br from-white via-white to-blue-500 text-transparent bg-clip-text drop-shadow-sm">
              Answers
            </span>
          </h2>
          <p className="text-gray-400 mx-auto max-w-2xl">
            We've gone ahead and answered some of the questions you might have.
          </p>
        </div>
        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="rounded-lg bg-gray-900/50 overflow-hidden"
            >
              <button
                className="w-full px-6 py-4 text-left flex items-center justify-between"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <span className="text-lg font-medium text-white">{faq.question}</span>
                <div className={`w-8 h-8 rounded-lg bg-blue-600/10 flex items-center justify-center transition-transform duration-200 ${openIndex === index ? 'rotate-45' : ''}`}>
                  <Plus className="h-5 w-5 text-blue-400 flex-shrink-0" />
                </div>
              </button>
              {openIndex === index && (
                <div className="px-6 pb-4">
                  <p className="text-gray-400">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}