import { ReactNode } from 'react';
import { cn } from '@/utils/cn';

interface ButtonProps {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  onClick?: () => void;
  fullWidth?: boolean;
}

export function Button({
  children,
  variant = 'primary',
  size = 'md',
  className,
  onClick,
  fullWidth = false,
  ...props
}: ButtonProps & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const baseStyles = "relative font-medium transition-all duration-200 active:scale-95";
  
  const variants = {
    primary: `
      bg-gradient-to-r from-blue-600 to-blue-700
      text-white
      shadow-[0_0_0_1px_rgba(37,99,235,0.1),0_1px_0_0_rgba(37,99,235,0.1)]
      hover:shadow-[0_0_0_1px_rgba(37,99,235,0.2),0_8px_20px_-6px_rgba(37,99,235,0.6)]
      hover:scale-[1.02]
      active:shadow-[0_0_0_1px_rgba(37,99,235,0.2),inset_0_1px_4px_rgba(0,0,0,0.3)]
      before:absolute before:inset-0 before:bg-gradient-to-b before:from-white/10 before:to-transparent
    `,
    secondary: `
      bg-gray-900/80
      text-white
      shadow-[0_0_0_1px_rgba(255,255,255,0.1)]
      hover:shadow-[0_0_0_1px_rgba(255,255,255,0.2),0_8px_20px_-6px_rgba(255,255,255,0.2)]
      hover:scale-[1.02]
      active:shadow-[0_0_0_1px_rgba(255,255,255,0.2),inset_0_1px_4px_rgba(0,0,0,0.3)]
      before:absolute before:inset-0 before:bg-gradient-to-b before:from-white/10 before:to-transparent
    `,
    outline: `
      bg-transparent
      border-2 border-blue-600
      text-blue-400
      hover:bg-blue-600/10
      hover:scale-[1.02]
      active:bg-blue-600/20
    `
  };

  const sizes = {
    sm: 'px-4 py-2 text-sm rounded-md',
    md: 'px-6 py-3 text-base rounded-lg',
    lg: 'px-8 py-4 text-lg rounded-lg'
  };

  return (
    <button
      className={cn(
        baseStyles,
        variants[variant],
        sizes[size],
        fullWidth && 'w-full',
        'overflow-hidden',
        className
      )}
      onClick={onClick}
      {...props}
    >
      <span className="relative z-10 flex items-center justify-center gap-2">
        {children}
      </span>
    </button>
  );
}