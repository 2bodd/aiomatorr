import { LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
}

export function ServiceCard({ title, description, icon: Icon }: ServiceCardProps) {
  return (
    <div className="group p-6 rounded-lg bg-gray-900/50 hover:bg-gray-900/70 transition-all duration-300">
      <div className="relative">
        <Icon className="h-12 w-12 text-blue-500 mb-4 transform group-hover:scale-110 transition-transform duration-300" />
        <h3 className="text-xl font-semibold text-white mb-2">{title}</h3>
        <p className="text-gray-400">{description}</p>
        <button className="mt-4 text-blue-400 hover:text-blue-300 font-medium inline-flex items-center">
          Learn More
          <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>
    </div>
  );
}