import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { useNavigation } from '@/utils/useNavigation';

export function FixedFooterCTA() {
  const [isVisible, setIsVisible] = useState(false);
  const [isChecked, setIsChecked] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30 * 60); // 30 minutes in seconds
  const { goToAnalysis } = useNavigation();

  useEffect(() => {
    // Check if the CTA was hidden in the last 24 hours
    const hiddenTimestamp = localStorage.getItem('ctaHiddenTimestamp');
    if (hiddenTimestamp) {
      const timeDiff = Date.now() - parseInt(hiddenTimestamp);
      if (timeDiff < 24 * 60 * 60 * 1000) { // 24 hours in milliseconds
        return;
      }
    }
    setIsVisible(true);
  }, []);

  useEffect(() => {
    if (!isVisible || timeLeft <= 0) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [isVisible, timeLeft]);

  const handleClose = () => {
    setIsVisible(false);
    localStorage.setItem('ctaHiddenTimestamp', Date.now().toString());
  };

  const handleAction = () => {
    if (isChecked) {
      goToAnalysis();
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[9999] bg-black/90 backdrop-blur-sm">
      {/* Countdown Timer */}
      <div className="text-center py-2 bg-yellow-600 text-white text-sm font-bold animate-pulse">
        ⏰ Offer expires in {formatTime(timeLeft)}
      </div>

      <div className="relative">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-2 right-2 text-white/60 hover:text-white transition-colors"
          aria-label="Close"
        >
          <X className="h-6 w-6" />
        </button>

        <div className="flex flex-col md:flex-row">
          {/* Left Side - Pain */}
          <div className="flex-1 bg-red-900 p-6 md:p-8">
            <div className="max-w-xl mx-auto">
              <h2 className="text-2xl md:text-3xl font-bold text-white mb-6 [text-shadow:_1px_1px_0_rgb(0_0_0_/_40%)]">
                🚨 DO NOTHING & KEEP LOSING
              </h2>
              <ul className="space-y-4 text-white/90">
                <li className="flex items-center gap-2">
                  <span className="text-red-300">✕</span>
                  Lose $257 daily to slow responses
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-red-300">✕</span>
                  Watch customers buy from Chewy/PetSmart
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-red-300">✕</span>
                  Waste 6h/day on repetitive questions
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-red-300">✕</span>
                  Pay $3,500/month for support staff
                </li>
              </ul>
            </div>
          </div>

          {/* Right Side - Solution */}
          <div className="flex-1 bg-green-900 p-6 md:p-8">
            <div className="max-w-xl mx-auto">
              <h2 className="text-2xl md:text-3xl font-bold text-white mb-6 [text-shadow:_1px_1px_0_rgb(0_0_0_/_40%)]">
                🚀 TAKE ACTION TODAY
              </h2>
              <ul className="space-y-4 text-white/90">
                <li className="flex items-center gap-2">
                  <span className="text-green-300">✓</span>
                  AI answers 83% of questions instantly
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-300">✓</span>
                  Save $3,500+ monthly on staff costs
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-300">✓</span>
                  Boost sales 40% while you sleep
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-300">✓</span>
                  7-day free trial - $0 risk
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom CTA Section */}
        <div className="bg-black/40 p-6 text-center">
          <p className="text-lg text-white/80 mb-6 font-semibold">
            YOUR BUSINESS. YOUR CHOICE.
          </p>
          <div className="max-w-md mx-auto">
            <div className="flex items-center justify-center gap-3 mb-2">
              <input
                type="checkbox"
                id="growth-checkbox"
                checked={isChecked}
                onChange={(e) => setIsChecked(e.target.checked)}
                className="w-5 h-5 rounded border-2 border-blue-400 bg-transparent checked:bg-blue-500 cursor-pointer"
              />
              <button
                onClick={handleAction}
                className={`px-8 py-3 text-lg font-bold rounded-lg transition-all duration-300 ${
                  isChecked
                    ? 'bg-blue-500 text-white hover:bg-blue-600'
                    : 'bg-gray-700 text-gray-300 cursor-not-allowed'
                }`}
              >
                👉 LOCK IN MY FREE TRIAL NOW
              </button>
            </div>
            <p className="text-sm text-gray-400">
              (Check this box if you're serious about growth)
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}