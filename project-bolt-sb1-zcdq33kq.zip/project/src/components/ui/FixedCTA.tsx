import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { useNavigation } from '@/utils/useNavigation';

export function FixedCTA() {
  const [isVisible, setIsVisible] = useState(false);
  const { goToAnalysis } = useNavigation();

  useEffect(() => {
    // Check if the CTA was hidden in the last 24 hours
    const hiddenTimestamp = localStorage.getItem('ctaHiddenTimestamp');
    if (hiddenTimestamp) {
      const timeDiff = Date.now() - parseInt(hiddenTimestamp);
      if (timeDiff < 24 * 60 * 60 * 1000) { // 24 hours in milliseconds
        return;
      }
    }
    setIsVisible(true);
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    localStorage.setItem('ctaHiddenTimestamp', Date.now().toString());
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[9999] bg-black/90 backdrop-blur-sm">
      <div className="relative">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-2 right-2 text-white/60 hover:text-white transition-colors"
          aria-label="Close"
        >
          <X className="h-6 w-6" />
        </button>

        <div className="flex flex-col md:flex-row">
          {/* Left Side - Pain */}
          <div className="flex-1 bg-[#7F1D1D] p-6 md:p-8">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-6 [text-shadow:_1px_1px_0_rgb(0_0_0_/_100%)]">
              🚨 DO NOTHING & KEEP LOSING
            </h2>
            <ul className="space-y-4 text-white [text-shadow:_1px_1px_0_rgb(0_0_0_/_100%)]">
              <li className="flex items-center gap-2">
                <span className="text-red-300">✕</span>
                Lose $257 daily to slow responses
              </li>
              <li className="flex items-center gap-2">
                <span className="text-red-300">✕</span>
                Watch customers buy from Chewy/PetSmart
              </li>
              <li className="flex items-center gap-2">
                <span className="text-red-300">✕</span>
                Waste 6h/day on repetitive questions
              </li>
              <li className="flex items-center gap-2">
                <span className="text-red-300">✕</span>
                Pay $3,500/month for support staff
              </li>
            </ul>
          </div>

          {/* Right Side - Solution */}
          <div className="flex-1 bg-[#14532D] p-6 md:p-8">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-6 [text-shadow:_1px_1px_0_rgb(0_0_0_/_100%)]">
              🚀 TAKE ACTION TODAY
            </h2>
            <ul className="space-y-4 text-white [text-shadow:_1px_1px_0_rgb(0_0_0_/_100%)]">
              <li className="flex items-center gap-2">
                <span className="text-green-300">✓</span>
                AI answers 83% of questions instantly
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-300">✓</span>
                Save $3,500+ monthly on staff costs
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-300">✓</span>
                Boost sales 40% while you sleep
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-300">✓</span>
                7-day free trial - $0 risk
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom CTA Section */}
        <div className="bg-black/40 p-6 text-center">
          <p className="text-lg text-white/80 mb-6 font-semibold [text-shadow:_1px_1px_0_rgb(0_0_0_/_100%)]">
            YOUR BUSINESS. YOUR CHOICE.
          </p>
          <button
            onClick={goToAnalysis}
            className="px-8 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-all duration-300 uppercase tracking-wide text-lg [text-shadow:_1px_1px_0_rgb(0_0_0_/_100%)]"
          >
            LOCK IN MY FREE TRIAL NOW
          </button>
        </div>
      </div>
    </div>
  );
}