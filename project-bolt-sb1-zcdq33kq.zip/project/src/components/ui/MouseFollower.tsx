import { useEffect, useRef } from 'react';
import { followMouse } from '@/utils/animations';

export function MouseFollower() {
  const followerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = followerRef.current;
    if (!element) return;

    const handleMouseMove = (e: MouseEvent) => followMouse(e, element);
    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return (
    <div
      ref={followerRef}
      className="pointer-events-none fixed w-64 h-64 rounded-full bg-blue-600/20 blur-3xl transition-transform duration-200"
      style={{ transform: 'translate(0, 0)' }}
    />
  );
}