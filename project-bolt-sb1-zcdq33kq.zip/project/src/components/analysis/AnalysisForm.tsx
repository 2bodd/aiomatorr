import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, Clock, Shield, Target } from 'lucide-react';
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';

export default function AnalysisForm() {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [showWorkflowDescription, setShowWorkflowDescription] = useState(false);
  const [showOtherHearAbout, setShowOtherHearAbout] = useState(false);
  const [hasWebsite, setHasWebsite] = useState<'yes' | 'no'>('yes');
  const [phone, setPhone] = useState('');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());

    // Add the phone number to the form data
    data.phone = phone;

    try {
      const response = await fetch('https://formsubmit.co/ajax/info@aiomator.com', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(data)
      });

      if (!response.ok) {
        throw new Error('Failed to submit form');
      }

      navigate('/thanks');
    } catch (err) {
      setError('Failed to submit form. Please try again.');
      setIsSubmitting(false);
    }
  };

  const handleAutomationTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setShowWorkflowDescription(e.target.value === 'full_workflow');
  };

  const handleHearAboutChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setShowOtherHearAbout(e.target.value === 'Other');
  };

  const inputClassName = 
    `w-full px-4 py-3 bg-gray-800/50 border border-blue-500/20 rounded-lg text-white placeholder-gray-400
    focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent
    transition-all duration-200`
  ;

  const RequiredLabel = () => (
    <span className="text-red-500 ml-1">*</span>
  );

  const budgetOptions = [
    { value: '100-1k', label: '$100-$1k monthly' },
    { value: '1k-3k', label: '$1k-$3k monthly' },
    { value: '3k+', label: '$3k+ monthly' },
    { value: 'guidance', label: 'Not Sure / Need Guidance' }
  ];

  const hearAboutOptions = [
    'Google Search',
    'Social Media (Instagram/Facebook)',
    'Referral from a Friend',
    'Online Ad',
    'Other'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black py-20">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center px-4 py-1 rounded-full bg-blue-600/10 border border-blue-500/20 text-blue-400 text-sm mb-6">
            <Clock className="w-4 h-4 mr-2" />
            Limited Offer: Free AI Blueprint for Pet Stores! 
          </div>
          <h1 className="text-4xl font-bold text-white mb-4">
            Get Your Personalized<br />
            <span className="bg-gradient-to-r from-blue-400 to-blue-600 text-transparent bg-clip-text">
              Pet Store AI Plan
            </span>
          </h1>
          <p className="text-gray-400 text-lg">
            Discover how AI can grow your sales, delight your customers, and save you hours of work — starting with a free analysis made just for your store
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500 rounded-lg text-red-500">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <input type="hidden" name="_captcha" value="false" />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">
                Full Name<RequiredLabel />
              </label>
              <input type="text" name="name" placeholder="Full Name" className={inputClassName} required />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">
                Email Address<RequiredLabel />
              </label>
              <input type="email" name="email" placeholder="Email Address" className={inputClassName} required />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">
                Store Name<RequiredLabel />
              </label>
              <input type="text" name="company" placeholder="Store Name" className={inputClassName} required />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">
                Phone Number<RequiredLabel />
              </label>
              <PhoneInput
                international
                defaultCountry="US"
                value={phone}
                onChange={setPhone}
                className={inputClassName}
                placeholder="Phone Number"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">
              What's your biggest challenge right now?<RequiredLabel />
            </label>
            <input type="text" name="most_impo_" placeholder="What's your biggest challenge right now?" className={inputClassName} required />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">
              What would you love to automate?<RequiredLabel />
            </label>
            <select name="automation_type" className={inputClassName} required onChange={handleAutomationTypeChange}>
              <option value="">Select an option</option>
              <option value="customer_support">24/7 Pet Product Support</option>
              <option value="order_tracking">Order Status & Tracking</option>
              <option value="product_recommendations">Pet Product Recommendations</option>
              <option value="full_workflow">Full Workflow (Describe below)</option>
            </select>
          </div>

          {showWorkflowDescription && (
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">
                Workflow Description<RequiredLabel />
              </label>
              <textarea
                name="workflow_description"
                placeholder="Please describe your current workflow and what you'd like to automate..."
                className={`${inputClassName} min-h-[120px]`}
                required
              />
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">
              Average Monthly Orders<RequiredLabel />
            </label>
            <select name="monthly_orders" className={inputClassName} required>
              <option value="">Select an option</option>
              <option value="0-50">0-50 orders</option>
              <option value="51-200">51-200 orders</option>
              <option value="201-500">201-500 orders</option>
              <option value="501+">501+ orders</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">
              What's your budget for growth?<RequiredLabel />
            </label>
            <select name="budget" className={inputClassName} required>
              <option value="">Select an option</option>
              {budgetOptions.map(option => (
                <option key={option.value} value={option.value}>{option.label}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">
              How did you hear about us?<RequiredLabel />
            </label>
            <select
              name="hear_about"
              className={inputClassName}
              required
              onChange={handleHearAboutChange}
            >
              <option value="">Select an option</option>
              {hearAboutOptions.map(option => (
                <option key={option} value={option}>{option}</option>
              ))}
            </select>
            {showOtherHearAbout && (
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-400 mb-1">
                  Please specify<RequiredLabel />
                </label>
                <input
                  type="text"
                  name="hear_about_other"
                  placeholder="Please specify how you heard about us..."
                  className={inputClassName}
                  required
                />
              </div>
            )}
          </div>

          <div className="space-y-4">
            <label className="block text-sm font-medium text-gray-400 mb-1">
              Do you have a website?<RequiredLabel />
            </label>
            <select 
              name="has_website"
              className={inputClassName}
              value={hasWebsite}
              onChange={(e) => setHasWebsite(e.target.value as 'yes' | 'no')}
              required
            >
              <option value="yes">I have a website/online store</option>
              <option value="no">I don't have a website yet</option>
            </select>

            {hasWebsite === 'yes' ? (
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">
                  Website URL<RequiredLabel />
                </label>
                <input type="url" name="website" placeholder="Website URL" className={inputClassName} required />
              </div>
            ) : (
              <div className="p-4 bg-blue-600/10 border border-blue-500/20 rounded-lg text-blue-400">
                No website yet? We can build you a fully customized site in just 48 hours!
              </div>
            )}
          </div>

          <div className="space-y-4">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 px-6 bg-gradient-to-r from-blue-600 to-blue-800 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 relative group"
            >
              <span className="relative z-10 flex items-center gap-2">
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    ANALYZING...
                  </>
                ) : (
                  <>
                    SEND ME MY FREE AI PLAN
                    <Target className="h-5 w-5 group-hover:animate-pulse" />
                  </>
                )}
              </span>
              <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-blue-400 to-blue-600 opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-200" />
            </button>

            <div className="flex items-center justify-center gap-2 text-sm text-gray-400">
              <Shield className="h-4 w-4 text-blue-400" />
              Your information is secure and will never be shared.
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}