export const smoothScroll = (elementId: string) => {
  const element = document.getElementById(elementId);
  if (element) {
    element.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  }
};

export const followMouse = (event: MouseEvent, element: HTMLElement) => {
  const { clientX, clientY } = event;
  const { left, top, width, height } = element.getBoundingClientRect();
  
  const x = clientX - left - width / 2;
  const y = clientY - top - height / 2;
  
  element.style.transform = `translate(${x}px, ${y}px)`;
};