import { useNavigate } from 'react-router-dom';
import { useEffect, useCallback } from 'react';

export const useNavigation = () => {
  const navigate = useNavigate();

  const goToAnalysis = useCallback(() => {
    navigate('/analysis');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [navigate]);

  const scrollToTop = useCallback(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const navigateAndScroll = useCallback((path: string) => {
    navigate(path);
    scrollToTop();
  }, [navigate, scrollToTop]);

  // Reset scroll position on route change
  useEffect(() => {
    scrollToTop();
  }, [scrollToTop]);

  return { goToAnalysis, navigateAndScroll };
};