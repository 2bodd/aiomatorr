import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import Hero from './components/home/Hero';
import ProblemSolution from './components/home/ProblemSolution';
import AnalysisForm from './components/analysis/AnalysisForm';
import Privacy from './pages/Privacy';
import Cookies from './pages/Cookies';
import Contact from './pages/Contact';
import About from './pages/About';
import Thanks from './pages/Thanks';
import SupportChaos from './pages/SupportChaos';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-black text-white">
        <Navbar />
        <Routes>
          <Route path="/" element={
            <>
              <Hero />
              <ProblemSolution />
            </>
          } />
          <Route path="/analysis" element={<AnalysisForm />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookies" element={<Cookies />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/about" element={<About />} />
          <Route path="/thanks" element={<Thanks />} />
          <Route path="/support-chaos" element={<SupportChaos />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;