import sharp from 'sharp';
import fs from 'fs/promises';
import path from 'path';

const sizes = [
  { width: 32, height: 32, name: 'favicon-32x32.png' },
  { width: 180, height: 180, name: 'apple-touch-icon.png' },
  { width: 192, height: 192, name: 'favicon-192x192.png' }
];

async function generateFavicons() {
  const inputPath = path.join(process.cwd(), 'public', 'favicon.png');
  const publicDir = path.join(process.cwd(), 'public');
  
  try {
    // Ensure the public directory exists
    await fs.mkdir(publicDir, { recursive: true });
    
    for (const size of sizes) {
      const outputPath = path.join(publicDir, size.name);
      
      await sharp(inputPath)
        .resize(size.width, size.height)
        .png()
        .toFile(outputPath);
        
      console.log(`Generated ${size.name}`);
    }
  } catch (error) {
    console.error('Error generating favicons:', error);
    process.exit(1);
  }
}

generateFavicons().catch(console.error);