import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs/promises';
import sharp from 'sharp';

// Generate favicons during build
const generateFavicons = async () => {
  const sizes = [
    { width: 32, height: 32, name: 'favicon-32x32.png' },
    { width: 180, height: 180, name: 'apple-touch-icon.png' },
    { width: 192, height: 192, name: 'favicon-192x192.png' }
  ];

  const inputPath = path.resolve(__dirname, 'public/favicon.png');
  const distDir = path.resolve(__dirname, 'dist');

  try {
    await fs.mkdir(distDir, { recursive: true });
    
    // Copy original favicon
    await fs.copyFile(inputPath, path.join(distDir, 'favicon.png'));
    
    // Generate and save different sizes directly to dist
    for (const size of sizes) {
      await sharp(inputPath)
        .resize(size.width, size.height)
        .png()
        .toFile(path.join(distDir, size.name));
    }
  } catch (error) {
    console.error('Failed to generate favicons:', error);
  }
};

export default defineConfig({
  plugins: [
    react(),
    {
      name: 'generate-favicons',
      async writeBundle() {
        await generateFavicons();
      },
    },
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
    rollupOptions: {
      input: {
        main: path.resolve(__dirname, 'index.html'),
      },
    },
  },
});